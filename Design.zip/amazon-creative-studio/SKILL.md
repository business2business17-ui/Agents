---
name: amazon-creative-studio
description: Create, adapt, localize, brief, validate, and preflight Amazon visual content from user-provided images, text, video, spreadsheets, or product assets. Use for Amazon listing carousel images, MAIN/secondary PDP images, listing video, 3D model preparation, Sponsored Brands and display creatives, A+ Basic, A+ Premium, Brand Story, Brand Store images/video, comparison-chart micro images, localization, designer briefs, and Amazon creative compliance checks. Preserve real product appearance exactly unless the user explicitly authorizes a conceptual mockup.
---

# Amazon Creative Studio

## Core objective

Build Amazon-ready creative plans, image/video prompts, localized copy, designer briefs, and preflight reports while preserving the real product exactly and applying placement-specific Amazon requirements.

Never invent an Amazon dimension, safe zone, limit, or policy. Distinguish:

- `AMAZON_REQUIRED`: explicitly required by an official Amazon source or current Amazon UI.
- `AMAZON_RECOMMENDED`: explicitly recommended by Amazon.
- `PRODUCTION_PRESET`: an internal quality choice that is stricter or more convenient than Amazon minimums.
- `VERIFY_IN_UI`: exact value is module-, marketplace-, account-, or UI-dependent and must be checked before final export.

Read `references/amazon-specs.md` before creating or validating Amazon assets.
Read `references/intake-and-approval.md` for mandatory questions and approval gates.
Read `references/carousel-strategy.md` when planning listing images 1-7.
Read `references/xlsx-output.md` when creating the production workbook.
Read `references/content-improvement.md` when turning TTX into stronger image copy, benefits, proof points, and category-specific content recommendations.
Read `references/universal-xlsx-intake.md` whenever the user supplies XLSX/CSV product data with arbitrary project-specific structure.
Read `references/agent-production-prompts.md` whenever another AI/content agent will execute the image, video, typography, compositing, or lifestyle generation work.

## Non-negotiable Product Fidelity Lock

For any user-provided product image or video, treat the actual product as an immutable protected layer. Read `references/product-fidelity.md` before any edit or generation involving a real product.

Do not alter the product itself unless the user explicitly requests a conceptual mockup. This includes logo, packaging text, proportions, shape, color, cap, label, typography, EAN/marks, quantity, product silhouette, or other identifying details.

Use compositing, masking, background replacement, layout, lighting around the product, shadows, graphic elements, native text layers, and environment generation around the protected product instead of regenerating the product.

If the available editing tool cannot guarantee fidelity, do not silently regenerate the product. Produce a safe compositing brief or request a workflow that preserves the source product layer.

## Supported inputs

Accept and analyze, when available:

- PNG, JPG, JPEG, WEBP
- MP4, MOV
- TXT, MD
- XLSX, CSV
- PDF
- GLB, GLTF

For XLSX/CSV, treat the user workbook as a universal read-only source that may use arbitrary sheets, headers, languages, projects, categories, and product types. Discover and map columns semantically rather than requiring a fixed template. Inspect product text, ASIN/EAN/GTIN, locale, claim, asset mapping, requested placements, and every product row independently. The product matrix may contain mixed categories and mixed product types. Do not assume one category/type applies to the whole workbook. Do not assume spreadsheet values are Amazon-compliant. Read `references/universal-xlsx-intake.md`.

For video, inspect duration, resolution, aspect ratio, codec/container if tooling permits, key product frames, embedded text, and product consistency.

For GLB/GLTF, treat geometry, scale, materials, textures, real-world dimensions, and reference-image fidelity as separate validation concerns.

## Workflow

Follow this sequence unless the user explicitly asks for only one subtask.

1. **Mandatory intake**
   - Identify supplied files and instructions.
   - Ask for or determine product category, product type, TTX/technical characteristics, brand/product/variant, target marketplace(s)/language(s), requested placements, and available source assets.
   - When an XLSX contains multiple products, first discover the workbook schema and map arbitrary source columns into normalized internal fields. Never require the user to pre-format the source workbook to this Skill's output template.
   - Classify each row/SKU separately. Category and product type are row-level fields, not workbook-level defaults.
   - If category or product type is missing, ambiguous, or inconsistent with TTX, propose the most likely value per row and ask the user to confirm/correct it before final content planning for that row.
   - Do not ask for any field already provided by the user.
   - TTX may arrive in Russian or any Amazon marketplace language; the agent must normalize and translate/localize it itself for each requested marketplace.
   - Follow `references/intake-and-approval.md`.

2. **Asset inspection**
   - Identify source dimensions/aspect ratio and whether product fidelity can be preserved.
   - Identify logos, packaging text, claims, languages, and likely protected product bounds.
   - Record risks: crop, illegible text, low resolution, distorted source, missing source angle, unsupported video specs.

3. **Product-row classification and content intelligence**
   - For every SKU/product row, establish Category, Product Type, normalized TTX, target shopper questions, and the strongest factual benefits.
   - Read `references/content-improvement.md`.
   - Propose improvements to image copy and product explanations based on category + product type + TTX.
   - Separate facts from benefits, proof points, usage guidance, objections, and claim-risk language.
   - Never invent a benefit that is not supported by TTX or source material.

4. **Placement mapping**
   - Map every requested asset to a specific Amazon placement.
   - Load the relevant row/rules from `references/amazon-specs.md`.
   - Never apply Store specs to A+, Sponsored Brands specs to PDP images, or one A+ module's dimensions to another without confirmation.

5. **Creative Plan**
   - Propose which source asset goes into which Amazon placement.
   - State intended output size/aspect ratio, text strategy, safe-zone strategy, localization, and whether product compositing or generation is used.
   - For every image/banner, describe the intended layout: what is shown, where the product sits, where each text block sits, what supporting graphics appear, and the reading order.
   - When layout is not predetermined, offer 1-3 layout options with a recommended default and ask the user to approve/change the proposed scheme.
   - Explicitly label Amazon rules versus production presets.

6. **Mandatory staged approval**
   - Work step by step and proactively recommend the best structure.
   - Use the Intake, Content Architecture, Copy/Layout, Production Package, and Final Preflight gates from `references/intake-and-approval.md`.
   - Ask for user approval after each substantive proposal before proceeding to final production for that stage.
   - If the user already approved or explicitly specified an element, do not ask again.
   - Do not block work on safe editable defaults; recommend a default and ask the user to approve or change it.

7. **Localization**
   - Read `references/localization.md`.
   - Translate for the target Amazon marketplace as concise marketing localization, not word-for-word translation.
   - Preserve factual meaning and claim scope.
   - Never strengthen a product claim during translation.

8. **Creation or brief**
   - For image creation/editing: keep the product layer protected and generate/edit only permitted regions.
   - For video: maintain product identity frame-to-frame; avoid morphing packaging or text.
   - For designer briefs: use `references/designer-brief.md` and output in RU, EN, or DE as requested.
   - When designers use AI agents, also generate an Agent-to-Agent Production Prompt from `references/agent-production-prompts.md` for each approved asset.
   - Before a designer brief is READY, create a concrete per-asset layout scheme: what appears on the image, product position/scale, exact text blocks, their zones, visual hierarchy, callouts/icons, supporting visuals, safe zones, and do-not-cover areas.
   - If any layout decision materially changes the creative and is not specified, propose 1-3 options, recommend one, and ask the user to approve it before finalizing the designer brief.

9. **Preflight**
   - Validate technical requirements where deterministic checks are possible.
   - Validate composition, safe-zone, copy, locale, policy, and product fidelity manually/visually.
   - Use `scripts/validate_asset.py` for image/video technical checks when local files are available.

10. **Final status**
   - Return one of:
     - `READY FOR AMAZON CREATIVE UPLOAD`
     - `READY AFTER USER-APPROVED CROP/EXPORT`
     - `NOT READY FOR AMAZON CREATIVE UPLOAD`
   - For `NOT READY`, list each failing asset, placement, issue, and correction required.

## Placement rules

### Listing / PDP carousel

Separate MAIN and secondary images.

For MAIN:
- apply official Amazon MAIN rules from `references/amazon-specs.md`;
- use a pure white background where required;
- show the real product, not an AI replacement;
- do not add external text, badges, borders, watermarks, or marketing graphics;
- do not crop the product;
- preserve product color and proportions.

Default internal production preset when the user wants standardized carousel production:
- 4000 x 4000 px;
- 1:1 canvas;
- high-quality JPG or PNG;
- MAIN product occupancy target 85-90% while remaining fully visible.

Always label 4000 x 4000 and 1:1 as `PRODUCTION_PRESET`, not universal Amazon mandatory dimensions.

For secondary images 2-7:
- use 1:1 / 4000 x 4000 as the internal preset for consistency unless otherwise required;
- actively propose what should appear on each image based on category, product type, TTX, shopper questions, claim constraints, and available source material;
- improve the content itself: rewrite raw TTX into concise shopper-facing benefits and proof points while preserving factual meaning;
- explain which TTX should be promoted, simplified, moved to a technical image, or omitted from image copy because it is too weak, redundant, or risky;
- use `references/carousel-strategy.md` for the default 2-7 storyline and adapt it rather than applying it mechanically;
- lifestyle, infographics, feature callouts, scale, use case, and detail imagery are allowed only when compliant with category/marketplace policies;
- maintain the protected product layer;
- get user approval for the proposed image-by-image plan before final production.

### Listing video

Confirm the upload surface and current Seller Central specs before final export. Do not reuse Sponsored Brands Video specifications automatically for PDP listing video.

### 3D model

Use a real product reference set and real-world dimensions. Preserve geometry, logo/label placement, proportions, materials, and color. Read `references/amazon-specs.md` and mark any category/account-specific upload details `VERIFY_IN_UI`.

### A+ Basic

Use the current Basic A+ maximum/general image canvas information as a guide, but treat exact image-box dimensions for individual modules as module-specific. Check the selected module in the current A+ builder before final export.

Basic A+ does not support Premium-only interactive features. Build concise mobile-legible creative, comparison content, and native text where suitable.

### A+ Premium

Use Premium-specific modules only when access is available. Support larger images, multiple videos, hotspots, enhanced comparison charts, navigation/carousel modules, and Q&A where offered.

Treat individual module asset boxes as `VERIFY_IN_UI` unless an exact official value is available in the reference table.

### A+ Brand Story

Treat Brand Story as a separate placement, not as a generic A+ banner.

- Plan the large carousel background separately from foreground cards.
- Plan desktop and mobile behavior separately.
- Keep important visual content away from card-covered areas and responsive crop areas.
- Do not hardcode third-party-published pixel dimensions for Brand Story background/cards as Amazon-required values unless confirmed by current Amazon UI or official documentation.
- When exact module dimensions are visible in Seller Central, use them as `AMAZON_REQUIRED` for that project and record the marketplace/date.

### Brand Store

Use exact Store specifications and safe-zone notes from `references/amazon-specs.md`.

Important:
- Store header hero: preserve central safe zone because Amazon may crop both sides.
- Image tiles may have link-title overlays that obscure the bottom portion.
- Prefer native Store text layers when feasible instead of baking long text into images.
- Design desktop and optional custom mobile images separately where the Store builder supports them.

### Sponsored Brands / brand advertising

Do not assume all Sponsored Brands creatives share one aspect ratio. Map image/video to the actual campaign creative type.

For Sponsored Brands Video use the official 16:9 video specs in `references/amazon-specs.md`.

For responsive/display creative, use the placement-specific sizes from the official ad-spec source and avoid embedding UI-like CTA elements when Amazon supplies them natively.

## Copy and text placement

Before placing text into an image or video:

1. Determine whether Amazon provides a native text field for that placement.
2. Prefer native text when it improves accessibility, responsiveness, indexing, or localization.
3. If embedded text is appropriate, keep it within safe areas and test at mobile display size.
4. Never cover or modify the product's own packaging text.
5. Use short, scannable marketing language.
6. Do not invent awards, certifications, rankings, discounts, medical claims, environmental claims, or comparative claims.

## A+ / Store / Brand Story content proposals

For A+ Basic, A+ Premium, Brand Store, and Brand Story, do not merely state dimensions. Propose:
- which modules/banners/media types to use;
- the job of each asset;
- headline/subheadline/supporting copy;
- whether text should be native or embedded;
- the visual concept and product placement;
- whether video is useful;
- comparison content where suitable;
- localization per marketplace;
- mobile/responsive/crop considerations;
- Product Fidelity Lock requirements.

Explain the recommendation and ask for user approval before final production.

## XLSX production package

When the project reaches production planning, create a separate XLSX workbook according to `references/xlsx-output.md`. One row must represent one asset. Keep the user's universal source XLSX unchanged by default and preserve source traceability where useful. Source references may be real URLs, Google Drive links, file paths/IDs, or text descriptions when an asset does not yet exist. Never invent URLs.

## Designer brief output

When the user requests a designer brief, read `references/designer-brief.md`.

Include at minimum:

- a concrete layout scheme / verbal wireframe for the asset;
- placement and marketplace;
- objective;
- output dimensions/aspect ratio and requirement status;
- source asset IDs/files;
- protected product instructions;
- composition;
- background/environment;
- text and localization;
- typography hierarchy;
- safe zones/crop risks;
- claim restrictions;
- animation/timing for video;
- export settings;
- QA checklist.

## Agent-to-Agent production prompts

When another content/image/video agent will execute the approved creative:

- generate one production prompt per asset;
- include source files/links, placement, canvas, layout, exact consumer-facing copy, background/decor instructions, product placement, safe zones, negative instructions, and QA;
- explicitly carry forward the Product Fidelity Lock;
- for text insertion, require exact approved copy and deterministic text compositing when the target generator cannot render typography reliably;
- for lifestyle creation, instruct the executing agent to generate only the environment around the protected product;
- for rear/back views, require an actual rear-view source image and never hallucinate a missing back panel or packaging side;
- produce separate prompts when text compositing and lifestyle/background generation should be done in separate passes;
- do not mark the production prompt FINAL until the user has approved the asset purpose, text, layout, source angle, and lifestyle/background direction or explicitly delegated those choices.

Read `references/agent-production-prompts.md`.

## MCP / connector behavior

Do not require a specific MCP server. Work with whichever compatible connector/tool is available for files, GitHub, Drive, DAM, Figma, or project storage.

If a connector is used:
- retrieve source assets without altering originals;
- write generated outputs to a new version/path unless the user explicitly requests overwrite;
- preserve filenames/IDs in the asset manifest;
- keep the Amazon spec reference independent from connector implementation.

## Reference maintenance

Amazon changes creative builders and ad specs. For any production-critical task involving dimensions, safe zones, video limits, or module availability:

- prefer current official Amazon Seller Central / Amazon Ads / sell.amazon sources;
- record verification date;
- update `references/amazon-specs.md` when an official value changes;
- never present an old third-party template as a current Amazon rule.
