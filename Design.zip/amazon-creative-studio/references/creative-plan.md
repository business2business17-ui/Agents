# Creative Plan Template

Present this before substantial final production when the user has not already supplied a complete composition.

| # | Placement | Source asset | Output | Product treatment | Text | Locale | Safe-zone / crop note | Status |
|---|---|---|---|---|---|---|---|---|

Then summarize:

- What will remain unchanged.
- What will be edited/generated.
- What requires user approval.
- Which dimensions are Amazon-required versus production presets.
- Any fields that remain VERIFY_IN_UI.
