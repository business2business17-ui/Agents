# Intake and Approval Workflow

## Mandatory intake questions

Before proposing final creative content for a new product, ask for or determine these fields. If the user already supplied a field, do not ask it again.

1. Product category for each product/SKU row.
2. Product type for each product/SKU row.
3. Product technical characteristics / TTX.
4. Brand and exact product/variant name.
5. Target Amazon marketplace(s) and language(s).
6. Requested placements: Listing carousel, A+ Basic, A+ Premium, Brand Store, Brand Story, advertising, listing video, 3D.
7. Available source assets: product images, lifestyle images, logos, video, copy, brand guide, reference creatives, URLs/Drive links/files.
8. Primary conversion goal or message priority when not obvious from the TTX.

TTX may be supplied in Russian or any Amazon marketplace language. Normalize the facts first. Then translate/localize them into each requested marketplace language according to `localization.md`.

A product matrix may contain unrelated categories and product types. Never infer that all rows share the same category/type just because they are in one workbook.

For each row:
1. Read product name/brand/variant/TTX.
2. Use supplied category/type if present.
3. If missing, propose the most likely category and type.
4. If ambiguous, mark `NEEDS CATEGORY/TYPE CONFIRMATION`.
5. Ask the user to confirm/correct only the ambiguous or missing rows.
6. Do not hold back clearly classifiable rows while waiting on unrelated ambiguous rows.

Do not require the user to supply translated TTX.

## Mandatory stage gates

Use these gates for substantial projects:

### Gate 1 - Intake confirmation
Summarize the understood products row by row: product ID/SKU, category, product type, TTX status, marketplaces, and available assets. Ask the user to correct only factual misunderstandings or ambiguous category/type assignments.

### Gate 2 - Content intelligence and architecture proposal
For each product, first propose the strongest content angles derived from category + product type + TTX: benefits, proof points, usage information, objections to answer, comparison opportunities, and risky/weak claims to avoid. Then propose what to communicate on each asset and why. Include carousel 1-7, selected A+ modules, Brand Store, Brand Story, and video only when relevant.

Ask for approval or edits before producing final production copy/briefs.

### Gate 3 - Copy and layout proposal
Show proposed headlines, subheads, benefits, comparison points, asset format, and placement notes. Ask for approval or edits.

### Gate 4 - Production package
After approval, create the XLSX production plan, designer briefs/prompts, localized copy, and/or generated assets requested by the user.

### Gate 5 - Preflight and final approval
Validate Amazon specs, Product Fidelity Lock, spelling/locale, technical format, crop/safe zones, and claims. Show issues and obtain final approval before marking the project ready.

## Do not over-question

Do not ask for information already supplied. Do not block on preferences that can safely be proposed as defaults. The agent must actively recommend a best option and ask the user to approve or change it.
