# Assets

Place reusable user-approved brand assets or safe-zone overlays here when needed. Do not bundle third-party copyrighted templates unless the user has rights to them. Keep the total packaged skill under 25 MB.
